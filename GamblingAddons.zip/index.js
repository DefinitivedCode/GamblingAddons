register("command", () => {
    const roll = (() => {
        const rand = Math.random();
        if (rand <= 1 / 666) return 7;
        if (rand <= 1 / 666 + 1 / 24) return 6;
        return Math.floor(Math.random() * 5) + 1;
    })();

    const clover = "☘";

    const extras = {
        1: [
            "Your luck seems quite poor today...",
            "Might not be the best day for risks.",
            "Fate is not smiling on you right now."
        ],
        2: [
            "Luck isn't on your side at the moment.",
            "Better watch your step today.",
            "Try to be cautious; luck is shaky."
        ],
        3: [
            "Your luck is average, keep going.",
            "Things might turn around soon.",
            "A balanced day for fortune."
        ],
        4: [
            "Luck is leaning in your favor.",
            "A good day to take chances.",
            "Fortune is on your side."
        ],
        5: [
            "Your luck is looking quite promising!",
            "Good things might be headed your way.",
            "Keep up the optimism!"
        ],
        6: [
            "PUT ALL ON RED TODAY!",
            "Feeling lucky? Go big or go home!",
            "This is your jackpot moment!"
        ],
        7: [
            "An extraordinary twist of fate!",
            "Luck beyond mortal comprehension!",
            "The universe has chosen you today..."
        ]
    };

    const extraMessage = extras[roll][Math.floor(Math.random() * extras[roll].length)];

    const responses = {
        1: `&eYour &7&lFAKE &6High Class Archfiend Dice &erolled a &c1&e!\n&c-300 ${clover} &lLuck!\n&7${extraMessage}`,
        2: `&eYour &7&lFAKE &6High Class Archfiend Dice &erolled a &c2&e!\n&c-200 ${clover} &lLuck!\n&7${extraMessage}`,
        3: `&eYour &7&lFAKE &6High Class Archfiend Dice &erolled a &c3&e!\n&c-100 ${clover} &lLuck!\n&7${extraMessage}`,
        4: `&eYour &7&lFAKE &6High Class Archfiend Dice &erolled a &a4&e!\n&a+100 ${clover} &lLuck!\n&7${extraMessage}`,
        5: `&eYour &7&lFAKE &6High Class Archfiend Dice &erolled a &a5&e!\n&a+200 ${clover} &lLuck!\n&7${extraMessage}`,
        6: `&eYour &7&lFAKE &6High Class Archfiend Dice &erolled a &56&e!\n&2+300 ${clover} &lLuck!\n&7${extraMessage}`,
        7: `&eYour &7&lFAKE &6High Class Archfiend Dice &erolled a &d7&e!\n&dWait, a 7? But dice only have 6 sides...\n&dHm...?\n&6The Dice broke apart, revealing an &dArchfiend Dye &6hidden within!\n&7${extraMessage}`
    };

    ChatLib.chat(responses[roll]);
}).setName("froll");

register("command", () => {
    const symbols = [
        "§e§l✦", // Yellow star
        "§c§l❤", // Red heart
        "§6§l❂", // Gold sun
        "§b§l✪", // Aqua star
        "§c§l7"  // Red 7
    ];

    let reels = ["", "", ""];
    let finalSymbols = [];
    let isSpinning = [true, true, true];

    ChatLib.chat("§e[§7§lFAKE §c§lCASINO §6§lSLOT§e] §3§lSpinning...");
    Client.showTitle("§eSpinning...", "", 10, 30, 10);

    function updateDisplay() {
        const spinDisplay = `§e[ §6${reels[0]} §f| §6${reels[1]} §f| §6${reels[2]} §e]`;
        Client.showTitle("", spinDisplay, 0, 15, 0);
        World.playSound("random.click", 1, 1);
    }

    function spinReel(index, delay, stopAfter) {
        let spins = 0;

        function spin() {
            if (spins < stopAfter) {
                reels[index] = symbols[Math.floor(Math.random() * symbols.length)];
                updateDisplay();
                spins++;
                setTimeout(spin, delay + spins * 5); // Gradually slow down
            } else {
                isSpinning[index] = false;
                finalSymbols[index] = reels[index];

                if (isSpinning.every(r => !r)) {
                    const finalDisplay = `§e[ §6${finalSymbols[0]} §f| §6${finalSymbols[1]} §f| §6${finalSymbols[2]} §e]`;
                    ChatLib.chat(finalDisplay);

                    const allSame = finalSymbols.every(sym => sym === finalSymbols[0]);

                    if (allSame) {
                        if (finalSymbols[0] === "§c§l7") {
                            ChatLib.chat("§6§lJACKPOT!!! §c§l777 WIN!");
                            Client.showTitle("§c§lJACKPOT!!!", finalDisplay, 10, 60, 20);
                            World.playSound("random.anvil_use", 1, 0.8);
                        } else {
                            ChatLib.chat(`§a§lWIN! Three ${finalSymbols[0]}§a§ls!`);
                            Client.showTitle("§a§lBIG WIN!", finalDisplay, 10, 50, 10);
                            World.playSound("random.levelup", 1, 1.2);
                        }
                    } else {
                        ChatLib.chat("§cNo luck this time, try again!");
                        Client.showTitle("§c§lRESULT", finalDisplay, 10, 50, 10);
                        World.playSound("random.break", 1, 0.9);
                    }
                }
            }
        }

        spin();
    }

    // Spin each reel with slightly different delay & duration
    spinReel(0, 50, 20);
    spinReel(1, 60, 24);
    spinReel(2, 70, 28);
}).setName("fslot");

register("command", (choice) => {
    const aliases = {
        r: "rock",
        p: "paper",
        s: "scissors"
    };

    if (!choice) {
        ChatLib.chat("&cUsage: /frps <rock | paper | scissors>");
        return;
    }

    choice = choice.toLowerCase();
    const fullChoice = aliases[choice] || choice;

    const options = ["rock", "paper", "scissors"];
    const symbols = {
        rock: "&8&l[R] Rock",
        paper: "&f&l[P] Paper",
        scissors: "&c&l✂ Scissors"
    };

    if (!options.includes(fullChoice)) {
        ChatLib.chat("&cUsage: /frps <rock | paper | scissors>");
        return;
    }

    const botChoice = options[Math.floor(Math.random() * 3)];

    ChatLib.chat(`&eYou chose: ${symbols[fullChoice]}`);
    ChatLib.chat(`&eOpponent chose: ${symbols[botChoice]}`);

    let result = "";

    if (fullChoice === botChoice) {
        result = "&6&lIt's a tie!";
    } else {
        const winMap = {
            rock: { beats: "scissors", msg: "&a&lROCK CRUSHES SCISSORS! YOU WIN!" },
            paper: { beats: "rock", msg: "&a&lPAPER COVERS ROCK! YOU WIN!" },
            scissors: { beats: "paper", msg: "&a&lSCISSORS CUT PAPER! YOU WIN!" }
        };

        const loseMap = {
            rock: { losesTo: "paper", msg: "&c&lPAPER COVERS ROCK! YOU LOSE!" },
            paper: { losesTo: "scissors", msg: "&c&lSCISSORS CUT PAPER! YOU LOSE!" },
            scissors: { losesTo: "rock", msg: "&c&lROCK CRUSHES SCISSORS! YOU LOSE!" }
        };

        if (botChoice === winMap[fullChoice]?.beats) {
            result = winMap[fullChoice].msg;
        } else {
            result = loseMap[fullChoice].msg;
        }
    }

    setTimeout(() => {
        ChatLib.chat(result);
    }, 1000);
}).setName("frps");

register("command", () => {
    const suggestions = [
        "&5Dragons Gambling",
        "&5M7 Runs",
        "&cKuudra Runs",
        "&aCrop Farming",
        "&eGold Mining",
        "&7Shaft Mining",
        "&dGemstone Mining",
        "&0Obsidian Mining",
        "&bDiamond Mining",
        "&6Lava Fishing",
        "&9Water Fishing",
        "&6Blaze Slayer",
        "&5Voidgloom Slayer",
        "&2Zombie Slayer",
        "&7Wolf Slayer",
        "&6Trophy Fishing",
        "&2Foraging",
        "&4Vampire Slayer",
        "&cPlay another game",
        "&5Dice Gamble",
        "&dF7 Dungeon",
        "&rSolo Clearing",
        "&5Mote Grinding"
    ];

    Client.showTitle("§b§l⟳ §c§lSpinning the Wheel §b§l⟳", "", 10, 40, 10);

    let spinCount = 0;
    const maxSpins = 15;

    function spinWheel() {
        if (spinCount < maxSpins) {
            const temp = suggestions[Math.floor(Math.random() * suggestions.length)];
            Client.showTitle("", `§e${temp}`, 0, 20, 0);

            // Gradually increase pitch (0.8 to 1.2)
            const pitch = 0.8 + (spinCount / maxSpins) * 0.4;
            World.playSound("random.click", 1, pitch);

            spinCount++;

            // Gradually increase delay to simulate slowing down
            const delay = 50 + (spinCount * 15);

            setTimeout(spinWheel, delay);
        } else {
            const finalPick = suggestions[Math.floor(Math.random() * suggestions.length)];
            Client.showTitle("§6§lYOU SHOULD", `§a${finalPick}`, 10, 60, 20);
            ChatLib.chat(`§6§lYOU SHOULD: §a${finalPick}`);

            // Final sound effect
            World.playSound("random.levelup", 1, 1);
        }
    }

    setTimeout(spinWheel, 500); // Delay after intro title
}).setName("fwob");

register("command", (...args) => {
    const corpses = parseInt(args[0]) || 1;
    ChatLib.chat("&7Scavenging Vanguard corpse" + (corpses > 1 ? "s..." : "..."));

    const drops = [
        ["Shattered Locket", 0.834, "&6&l", "Legendary", 1_000_000_000],
        ["Skeleton Key", 1.663, "&6", "Epic", 30_000_000],
        ["Umber Key (4)", 2.759, "&5", "Rare", 2_500_000],
        ["Tungsten Key (4)", 2.759, "&5", "Rare", 2_500_000],
        ["Mithril Plate", 8.085, "&5", "Rare", 7_500_000],
        ["Fine Onyx Gemstone (160)", 10.654, "&9", "Uncommon", 25_000],
        ["Fine Peridot Gemstone (160)", 10.654, "&9", "Uncommon", 25_000],
        ["Fine Citrine Gemstone (160)", 10.654, "&9", "Uncommon", 25_000],
        ["Fine Aquamarine Gemstone (160)", 10.654, "&9", "Uncommon", 25_000],
        ["Glacite Amalgamation (4)", 10.654, "&5", "Rare", 0],
        ["Umber Key (2)", 13.161, "&5", "Rare", 2_500_000],
        ["Tungsten Key (2)", 13.161, "&5", "Rare", 2_500_000],
        ["Dwarven O's Metallic Minis", 13.161, "&6", "Epic", 0],
        ["Umber Plate", 13.161, "&9", "Common", 0],
        ["Tungsten Plate", 13.161, "&9", "Common", 0],
        ["Refined Mithril (2)", 15.608, "&5", "Common", 0],
        ["Refined Titanium (2)", 15.608, "&6", "Common", 0],
        ["Blue Goblin Egg (4)", 17.905, "&3", "Common", 1_500_000],
        ["Flawless Onyx Gemstone", 20.326, "&5", "Rare", 2_500_000],
        ["Flawless Peridot Gemstone", 20.326, "&5", "Rare", 2_500_000],
        ["Flawless Citrine Gemstone", 20.326, "&5", "Rare", 2_500_000],
        ["Flawless Aquamarine Gemstone", 20.326, "&5", "Rare", 2_500_000],
        ["Refined Umber", 20.326, "&9", "Uncommon", 2_000_000],
        ["Refined Tungsten", 20.326, "&9", "Uncommon", 2_000_000],
        ["Glacite Amalgamation (2)", 20.326, "&5", "Rare", 0],
        ["Umber Key", 24.818, "&5", "Common", 2_500_000],
        ["Tungsten Key", 24.818, "&5", "Common", 2_500_000],
        ["Blue Goblin Egg (2)", 33.161, "&3", "Common", 1_500_000],
        ["Suspicious Scrap (4)", 35.117, "&9", "Uncommon", 200_000],
        ["Ice Cold I", 35.117, "&f", "Common", 5_000_000],
        ["Bejeweled Handle (4)", 35.117, "&9", "Uncommon", 200_000],
        ["Frostbitten Dye", 0.06698091, "&3", "Legendary", 400_000_000]
    ];

    const getRarityTag = rarity => {
        switch (rarity) {
            case "Legendary": return "&6[✪]";
            case "Epic": return "&5[✦]";
            case "Rare": return "&9[✧]";
            case "Uncommon": return "&a[UC]";
            case "Common": return "&7[C]";
            default: return "";
        }
    };

    const formatNameWithIcon = (name, rarity) => {
        if (rarity === "Legendary") return `★ ${name}`;
        if (rarity === "Epic") return `✦ ${name}`;
        if (rarity === "Rare") return `✧ ${name}`;
        return name;
    };

    const formatAbbreviated = num => {
        if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(2) + "B";
        if (num >= 1_000_000) return (num / 1_000_000).toFixed(2) + "M";
        if (num >= 1_000) return (num / 1_000).toFixed(1) + "K";
        return num.toString();
    };

    const results = {};
    let totalGlacitePowder = 0;

    for (let i = 0; i < corpses; i++) {
        drops.forEach(([fullName, chance]) => {
            if (Math.random() * 100 < chance) {
                const baseName = fullName.replace(/\s*\(\d+\)/, "");
                const quantityMatch = fullName.match(/\((\d+)\)/);
                const quantity = quantityMatch ? parseInt(quantityMatch[1]) : 1;
                if (!results[baseName]) results[baseName] = 0;
                results[baseName] += quantity;
            }
        });
        totalGlacitePowder += Math.floor(Math.random() * (100_000 - 30_000 + 1)) + 30_000;
    }

    setTimeout(() => {
        let totalValue = 0;
        ChatLib.chat(`&aIn ${corpses} Vanguard${corpses > 1 ? "s" : ""} you got:`);

        Object.entries(results)
            .sort((a, b) => b[1] - a[1])
            .forEach(([baseName, count]) => {
                const drop = drops.find(([name]) => name.includes(baseName));
                if (!drop) return;

                const [__, ___, color, rarity, price] = drop;
                const rarityTag = getRarityTag(rarity);
                const displayName = formatNameWithIcon(baseName, rarity);
                ChatLib.chat(`&a${formatAbbreviated(count)}&7x ${color}${displayName} &r${rarityTag}`);
                totalValue += (price || 0) * count;
            });

        ChatLib.chat(`&bTotal Glacite Powder Gained: &3${formatAbbreviated(totalGlacitePowder)}`);

const totalCost = corpses * 30_000_000;
const profit = totalValue - totalCost;

const formattedTotalValue = formatAbbreviated(totalValue);
const formattedTotalCost = formatAbbreviated(totalCost);
const formattedProfit = formatAbbreviated(Math.abs(profit));
const profitColor = profit >= 0 ? "&a" : "&c";

ChatLib.chat("&e-----------------------------------");
ChatLib.chat(`&6Total Loot Value: &a${formattedTotalValue} coins`);
ChatLib.chat(`&6Opening Cost: &c${formattedTotalCost} coins`);
ChatLib.chat(`&6Profit: ${profitColor}${formattedProfit} coins`);
ChatLib.chat("&e-----------------------------------");


    }, 1000);

}).setName("fvanguard");


register("command", (...args) => {
    const runs = parseInt(args[0]) || 1;
    ChatLib.chat("&7Running Master Mode Floor 7 dungeon" + (runs > 1 ? "s..." : "..."));

    const drops = [
        ["Necron's Handle", 0.129, "&6&l", "Legendary", 850_000_000, 100_000_000],
        ["Shadow Warp", 0.179, "&5", "Legendary", 250_000_000, 50_000_000],
        ["Wither Shield", 0.179, "&5", "Legendary", 250_000_000, 50_000_000],
        ["Implosion", 0.179, "&5", "Legendary", 250_000_000, 50_000_000],
        ["Dark Claymore", 0.079, "&6", "Legendary", 160_000_000, 150_000_000],
        ["Fifth Master Star", 0.215, "&5", "Epic", 90_000_000, 9_000_000],
        ["Wither Chestplate", 0.1, "&6", "Epic", 11_000_000, 10_000_000],
        ["Wither Leggings", 0.1, "&6", "Epic", 7_000_000, 6_000_000],
        ["Wither Helmet", 0.1, "&6", "Epic", 2_000_000, 1_000_000],
        ["Wither Boots", 0.1, "&6", "Epic", 1_500_000, 1_000_000],
        ["Auto Recombobulator", 0.1, "&6", "Legendary", 11_000_000, 10_000_000],
        ["Recombobulator 3000", 0.1, "&6", "Legendary", 9_000_000, 6_000_000],
        ["Soul Eater I", 0.1, "&d&l", "Rare", 1_500_000, 1_000_000],
        ["Hot Potato Book", 0.1, "&5", "Uncommon", 50_000, 100_000],
        ["Precursor Gear", 0.1, "&5", "Uncommon", 600_000, 500_000],
        ["No Pain No Gain II", 0.1, "&d&l", "Uncommon", 0, 0],
        ["Combo II", 0.1, "&d&l", "Uncommon", 0, 0],
        ["Rejuvenate III", 7.197, "&r", "Uncommon", 100_000, 0],
        ["Bank III", 5.998, "&d&l", "Uncommon", 10_000, 0],
        ["Wisdom II", 3.598, "&d&l", "Uncommon", 200_000, 0],
        ["Ultimate Wise II", 5.758, "&d&l", "Uncommon", 200_000, 0],
        ["Ultimate Jerry III", 4.318, "&d&l", "Uncommon", 0, 0],
        ["Last Stand II", 7.197, "&d&l", "Uncommon", 200_000, 0],
        ["Infinite Quiver VII", 7.197, "&9", "Common", 0, 0],
        ["Feather Falling VII", 2.303, "&9", "Common", 0, 0],
        ["Storm The Fish", 0.035, "&c", "Common", 50_000, 0],
        ["Maxor The Fish", 0.035, "&c", "Common", 50_000, 0],
        ["Goldor The Fish", 0.035, "&c", "Common", 50_000, 0],
        ["Thunderlord VII", 0.0143, "&5", "Legendary", 7_500_000, 2_000_000],
        ["Wither Cloak Sword", 3.4, "&5", "Rare", 3_600_000, 2_000_000],
        ["Wither Catalyst", 2.87, "&9", "Rare", 1_300_000, 1_000_000],
        ["Wither Blood", 3.4, "&5", "Rare", 3_500_000, 3_000_000],
        ["One For All I", 0.57, "&d&l", "Epic", 2_500_000, 2_000_000],
        ["Master Skull - Tier 5", 0.172, "&9", "Legendary", 32_000_000, 30_000_000],
        ["Wither Essence", 0, "&8", "Common", 0, 0],
        ["Undead Essence", 0, "&8", "Common", 0, 0],
        ["Old Disc", 0, "&6", "Legendary", 5_000_000, 0]
    ];

    const getRarityTag = rarity => {
        switch (rarity) {
            case "Legendary": return "&6[✪]";
            case "Epic": return "&5[✦]";
            case "Rare": return "&9[✧]";
            case "Uncommon": return "&a[UC]";
            case "Common": return "&7[C]";
            default: return "";
        }
    };

    const formatNameWithIcon = (name, rarity) => {
        if (rarity === "Legendary") return `★ ${name}`;
        if (rarity === "Epic") return `✦ ${name}`;
        if (rarity === "Rare") return `✧ ${name}`;
        return name;
    };

    const formatAbbreviated = num => {
        if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(2) + "B";
        if (num >= 1_000_000) return (num / 1_000_000).toFixed(2) + "M";
        if (num >= 1_000) return (num / 1_000).toFixed(1) + "K";
        return num.toString();
    };

    const results = {};
    let totalValue = 0;
    let totalCost = 0;
    let totalWitherEssence = 0;
    let totalUndeadEssence = 0;

    for (let i = 0; i < runs; i++) {
        drops.forEach(([name, chance, color, rarity, price, cost]) => {
            if (Math.random() * 100 < chance) {
                if (!results[name]) results[name] = 0;
                results[name]++;
                totalValue += price;
                totalCost += cost;
            }
        });

        totalWitherEssence += Math.floor(Math.random() * 51) + 100; // 100–150
        totalUndeadEssence += Math.floor(Math.random() * 51) + 100; // 100–150
    }

    setTimeout(() => {
        ChatLib.chat(`&aIn ${runs} Master Mode Floor 7 run${runs > 1 ? "s" : ""} you got:`);

        Object.entries(results)
            .sort((a, b) => b[1] - a[1])
            .forEach(([name, count]) => {
                const drop = drops.find(([n]) => n === name);
                if (!drop) return;
                const [__, ___, color, rarity] = drop;
                const rarityTag = getRarityTag(rarity);
                const displayName = formatNameWithIcon(name, rarity);
                ChatLib.chat(`&a${formatAbbreviated(count)}&7x ${color}${displayName} &r${rarityTag}`);
            });

        const profit = totalValue - totalCost;

        ChatLib.chat("&e-----------------------------------");
        ChatLib.chat(`&6Total Loot Value: &a${formatAbbreviated(totalValue)} coins`);
        ChatLib.chat(`&6Opening Cost: &c${formatAbbreviated(totalCost)} coins`);
        ChatLib.chat(`&6Profit: ${profit >= 0 ? "&a" : "&c"}${formatAbbreviated(profit)} coins`);
        ChatLib.chat(`&8Wither Essence Gained: &7${formatAbbreviated(totalWitherEssence)}`);
        ChatLib.chat(`&8Undead Essence Gained: &7${formatAbbreviated(totalUndeadEssence)}`);
        ChatLib.chat("&e-----------------------------------");

    }, 1000);

}).setName("fm7");

// Slayer Drop Simulator
register("command", (...args) => {
    const [slayer, amountArg, magicFindArg] = args;
    const runs = parseInt(amountArg) || 1;
    const magicFind = parseFloat(magicFindArg) || 0;
    const type = slayer?.toLowerCase();

    const lootTables = {
        zombie: [
            ["Revenant Flesh", 100, "&a", "Common", 150, [63, 64]],
            ["Foul Flesh", 13.7, "&9", "Uncommon", 25000, [3, 4]],
            ["Revenant Viscera", 13.7, "&9", "Uncommon", 70000, [1, 2]],
            ["Pestilence Rune I", 5.4, "&2", "Uncommon", 10000],
            ["Undead Catalyst", 1.7, "&9", "Rare", 10000],
            ["Revenant Catalyst", 0.8, "&5", "Rare", 20000],
            ["Smite VI Book", 0.68, "&9", "Epic", 100],
            ["Smite VII Book", 0.048, "&9", "Legendary", 7500000],
            ["Beheaded Horror", 0.13, "&5", "Legendary", 75000],
            ["Snake Rune I", 0.13, "&a", "Legendary", 75000],
            ["Scythe Blade", 0.103, "&6", "Legendary", 10000000],
            ["Shard Of The Shredded", 0.055, "&6", "Legendary", 15000000],
            ["Warden Heart", 0.014, "&6", "RNGesus", 200000000],
            ["Matcha Dye", 0.000004, "&2", "RNGesus Incarnate", 100000000]
        ],
        wolf: [
            ["Wolf Tooth", 100, "&a", "Common", 850, [50, 64]],
            ["Hamster Wheel", 16.225, "&9", "Uncommon", 22000, [4, 5]],
            ["Spirit Rune", 6.3, "&b", "Uncommon", 40000],
            ["Critical VI Book", 0.8, "&9", "Rare", 10000],
            ["Furball", 1.6, "&9", "Rare", 56000],
            ["Red Claw Egg", 0.12, "&5", "Legendary", 300000],
            ["Couture Rune I", 0.227, "&6", "Legendary", 600000],
            ["Overflux Capacitor", 0.041, "&5", "Legendary", 100000000],
            ["Grizzly Salmon", 0.057, "&9", "RNGesus", 600000],
            ["Celeste Dye", 0.000002, "&b", "RNGesus Incarnate", 5000000000]
        ],
        voidgloom: [
            ["Null Sphere", 100, "&a", "Common", 220, [105, 155]],
            ["Twilight Arrow Poison", 7.8, "&a", "Uncommon", 1700, [60, 64]],
            ["Endersnake Rune I", 5.2, "&5", "Uncommon", 5000],
            ["Summoning Eye", 0.56, "&5", "Uncommon", 1200000],
            ["Mana Steal I Book", 4.2, "&9", "Uncommon", 20000],
            ["Transmission Tuner", 2.1, "&5", "Rare", 15000],
            ["Null Atom", 5, "&9", "Rare", 35000],
            ["Hazmat Enderman", 1.5, "&6", "Rare", 300000],
            ["Pocket Espresso Machine", 0.38, "&r", "Legendary", 250000],
            ["Smarty Pants I Book", 1.7, "&9", "Epic", 400000],
            ["End Rune I", 0.6, "&5", "Epic", 20000],
            ["Handy Blood Chalice", 0.17, "&r", "Legendary", 1000000],
            ["Sinful Dice", 0.4, "&5", "Epic", 200000],
            ["Exceedingly Rare Ender Artifact Upgrader", 0.028, "&6", "Legendary", 200000],
            ["Void Conqueror Enderman Skin", 0.166, "&d", "Legendary", 500000],
            ["Etherwarp Merger", 0.43, "&5", "Legendary", 200000],
            ["Judgement Core", 0.056, "&6", "RNGesus", 250000000],
            ["Enchant Rune I", 0.046, "&7", "RNGesus Incarnate", 4000000],
            ["Ender Slayer VII Book", 0.014, "&5", "RNGesus Incarnate", 75000000],
            ["Byzantium Dye", 0.000002 , "&5", "RNGesus Incarnate", 400000000],
        ],
        blaze: [
            ["Derelict Ashe", 100, "&a", "Common", 1900, [110, 155]],
            ["Wisp's Ice-Flavored Water", 2.5, "&r", "Rare", 250000,],
            ["Bundle of Magma Arrows", 7, "&5", "Uncommon", 200000],
            ["Mana Disintegrator", 3.5, "&9", "Rare", 20000],
            ["Scorched Books", 2.02, "&d", "Rare", 65000],
            ["Kelvin Inverter", 2.5, "&9", "Rare", 100000],
            ["Blaze Rod Distillate", 4.2, "&9", "Rare", 35000, [16, 24]],
            ["Glowstone Distillate", 4.2, "&9", "Rare", 60000, [16, 24]],
            ["Magma Cream Distillate", 4.2, "&9", "Rare", 35000, [16, 24]],
            ["Nether Wart Distillate", 4.2, "&9", "Rare", 60000, [16, 24]],
            ["Gabagool Distillate", 4.2, "&9", "Rare", 50000, [16, 24]],
            ["Enchanted Blaze Powder", 11.727, "&a", "Uncommon", 4500, [16, 40]],
            ["Flawed Opal Gemstone", 2.78, "&a", "Uncommon", 1000, [240, 400]],
            ["Scorched Powder Crystal", 3, "&6", "Legendary", 1000000],
            ["Fiery Burst Rune I", 0.174, "&c", "RNGesus", 250000],
            ["Archfiend Dice", 1.011, "&5", "Epic", 4500000],
            ["Fire Aspect III Book", 1.2, "&r", "Rare", 100000],
            ["Duplex I Book", 1.7, "&d&l", "Epic", 1500000],
            ["Lavatears Rune I", 1.9, "&c", "Epic", 75000],
            ["High Class Archfiend Dice", 0.21, "&6", "RNGesus", 35000000],
            ["Wilson's Engineering Plans", 0.086, "&6", "RNGesus", 2000000],
            ["Subzero Inverter", 0.086, "&6", "RNGesus", 2000000],
            ["Flame Dye", 0.000002, "&6", "RNGesus Incarnate", 450000000],
        ],
        vampire: [
            ["Coven Seal", 100, "&4", "Common", 500, [64, 128]],
            ["Quantum Book Bundle", 11.98, "&d", "Rare", 1000000],
            ["Soultwist Rune", 10.6, "&5", "Rare", 750000],
            ["Bubba Blister", 8.9, "&5", "Rare", 750000],
            ["Fang-Tastic Chocolate Chip", 8.9, "&5", "Rare", 750000],
            ["McGrubber's Burger", 1.198, "&d", "RNGesus", 5000000],
            ["Unfanged Vampire Part", 1.198, "&d", "RNGesus", 5000000],
            ["The One Book Bundle", 1.7, "&d", "RNGesus", 10000000],
            ["Sangria Dye", 0.01, "&d", "RNGesus Incarnate", 200000000]
        ]
    };

    const spawnCosts = {
        zombie: 50000,
        wolf: 50000,
        voidgloom: 50000,
        blaze: 75000,
        vampire: 75000
    };

    if (!lootTables[type]) {
        ChatLib.chat("&cUsage: /fslayer [zombie/wolf/voidgloom/blaze/vampire&c(WIP)&7] [Number of Bosses] [Magic Find]");
        return;
    }

    const getRarityTag = rarity => {
        switch (rarity) {
            case "Legendary": return "&6[✪]";
            case "Epic": return "&5[✦]";
            case "Rare": return "&9[✧]";
            case "Uncommon": return "&a[UC]";
            case "Common": return "&7[C]";
            case "RNGesus": return "&d[✽]";
            case "RNGesus Incarnate": return "&d[✸]";
            default: return "";
        }
    };

    const formatNameWithIcon = (name, rarity) => {
        if (rarity === "Legendary") return `★ ${name}`;
        if (rarity === "Epic") return `✦ ${name}`;
        if (rarity === "Rare") return `✧ ${name}`;
        return name;
    };

    const formatAbbreviated = num => {
        const absNum = Math.abs(num);
        if (absNum >= 1_000_000_000) return (num / 1_000_000_000).toFixed(2) + "B";
        if (absNum >= 1_000_000) return (num / 1_000_000).toFixed(2) + "M";
        if (absNum >= 1_000) return (num / 1_000).toFixed(1) + "K";
        return num.toString();
    };

    ChatLib.chat(`&7Slaying ${type} slayer${runs > 1 ? "s" : ""} with &b${magicFind}% ✯ Magic Find&7...`);

    const drops = lootTables[type];
    const results = {};
    let totalValue = 0;
    const spawnCost = spawnCosts[type] * runs;

    for (let i = 0; i < runs; i++) {
        drops.forEach(([name, baseChance, color, rarity, value, range]) => {
            const mfMultiplier = 1 + (magicFind / 100);
            const adjustedChance = baseChance >= 100 ? 100 : baseChance * mfMultiplier;
            if (Math.random() * 100 < adjustedChance) {
                const quantity = range ? Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0] : 1;
                if (!results[name]) results[name] = 0;
                results[name] += quantity;
                totalValue += value * quantity;
            }
        });
    }

    setTimeout(() => {
        ChatLib.chat(`&aIn ${runs} ${type} slayer boss${runs > 1 ? "es" : ""} you got:`);
        Object.entries(results)
            .sort((a, b) => b[1] - a[1])
            .forEach(([name, count]) => {
                const drop = drops.find(([n]) => n === name);
                if (!drop) return;
                const [__, ___, color, rarity] = drop;
                const rarityTag = getRarityTag(rarity);
                const displayName = formatNameWithIcon(name, rarity);
                ChatLib.chat(`&a${formatAbbreviated(count)}&7x ${color}${displayName} &r${rarityTag}`);
            });

        const profit = totalValue - spawnCost;
        const profitColor = profit >= 0 ? "&a" : "&c";

        ChatLib.chat("&e-----------------------------------");
        ChatLib.chat(`&6Total Loot Value: &a${formatAbbreviated(totalValue)} coins`);
        ChatLib.chat(`&6Spawn Cost: &c${formatAbbreviated(spawnCost)} coins`);
        ChatLib.chat(`&6Profit: ${profitColor}${formatAbbreviated(profit)} coins`);
        ChatLib.chat("&e-----------------------------------");

    }, 1000);
}).setName("fslayer");

register("command", () => {
    ChatLib.chat("&b&lAvailable Commands:");
    ChatLib.chat("&a/froll &7- Roll a Dice");
    ChatLib.chat("&a/fslot &7- Slot machine");
    ChatLib.chat("&a/frps &7- Rock, Paper, Scissors (use /frps r/p/s)");
    ChatLib.chat("&a/fwob &7- Wheel of Boredness");
    ChatLib.chat("&a/fvanguard &7- Vanguard loot simulator (/fvanguard [Number of Corpses])");
    ChatLib.chat("&a/fm7 &7- Simulate Floor 7 dungeon drops (/fm7 [Number of Runs])");
    ChatLib.chat("&a/fslayer &7- Simulate Slayer drops (/fslayer [zombie / wolf / voidgloom / blaze / vampire &c(WIP)&7] [Number of Bosses] [Magic Find])");
}).setName("gahelp");
